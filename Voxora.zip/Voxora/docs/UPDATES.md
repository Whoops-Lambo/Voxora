# Desktop updates and release publishing

Install **Voxora 2.16.0 manually** if an earlier updater shows “Download and verify an update before installing” or closes the app without installing/reopening it. Close Voxora and run the new installer; your data is preserved. Versions before 2.8 have no update checker. Automatic updates support the installed Windows x64 app; source-mode Electron and other operating systems show an unsupported status.

In 2.14 and 2.15, a background/focus check could change a verified update to `checking` while the restart confirmation was open. Confirming then failed with “Download and verify an update before installing.” Install 2.15.1 manually once to replace that desktop handler. The patch pins the approved release, pauses checks during confirmation and prevents late checks from changing an active installation. Choosing Later preserves the download and resumes polling.

Versions before 2.14 could launch Windows PowerShell with a detached-process flag that exits successfully without executing the helper. Install 2.15 manually once if Restart and Install fails. The corrected handoff uses a short-lived Windows launcher to start an independent hidden helper. Voxora validates its process ID and matching readiness acknowledgement before closing.

## Local setup and shared connections

Choose **Open Local Workspace** to use Voxora without a domain or hosted server. The optional shared-server field starts blank. Failed shared connections never create a replacement local backend. **Voxora → Server Connection** lets you reopen a private workspace or choose any supported shared backend. Desktop updates work independently of your workspace address. See [local/shared hosting and migration](SHARED-PLATFORM.md).

## Receiving updates

Voxora checks two seconds after startup and every minute while open. It also checks after waking or focusing the app and reconnecting to the network. Failed checks/downloads retry after 15 seconds, with exponential backoff up to five minutes. Manual checks bypass the background cooldown. Downloads are automatic by default. **User Settings → Updates** lets you disable automatic downloads, check manually, download a release, inspect progress/notes, and select **Restart and Install**. Press Alt for the native **Voxora** menu when connected to a backend whose web UI predates this feature.

A native dialog always asks before a restart. Select **Later** to keep chatting. Before closing Voxora, the app waits up to 30 seconds for the independent helper to verify the installer and check installation access. If the helper cannot start, Voxora stays open with an error. The helper uses explicit UTF-8 for paths, including non-English Windows usernames. Installing disconnects calls, cleanly closes the local backend, waits for the app and its file locks to exit, and runs the installer silently in the existing installation directory. It checks the installed version, relaunches the app, and waits for a startup confirmation unique to this update attempt. A successfully opened connection-setup screen also confirms startup; the helper does not require a working shared server or a private backend to acknowledge the new desktop. The installer preserves `%APPDATA%\Voxora\chat-data`, browser sessions/preferences, and the saved server connection. It does not upgrade a remote backend or a separately running bot process.

The updater uses a fixed HTTPS feed at `https://raw.githubusercontent.com/Whoops-Lambo/Voxora/main/updates/stable.json`. Feed entries must reference a full commit SHA and the matching version's installer in the official repository. Direct download redirects cannot switch repositories or commits. If that host is blocked or unavailable, the app resolves the exact public Git LFS object through the official repository and accepts only GitHub storage URLs whose path matches the expected SHA-256. Signed storage URLs stay temporary and are not exposed in diagnostics. SHA-256, exact size, and Windows executable headers are verified before a download is marked ready and again at installation. Older or equal versions are never installed. Requests use Electron's networking and system proxy settings, without account cookies or bot tokens.

Updates are **unsigned**. Checksums verify the bytes published by the official GitHub repository; they do not provide a code-signing identity independent of that repository. The repository and feed must remain publicly readable. The app bypasses the mutable feed cache on each check. Windows CI validates fresh installation, the installed setup button without a domain, local/shared startup, real helper handoff, production installer execution, desktop relaunch, reinstallation and uninstall. The update-cycle test supplies fixture network responses for the production installer bytes; it executes the actual Windows helper, installer and desktop. A separate live check downloads and verifies the published installer through the public GitHub transport.

Update availability, download progress and failures appear outside Settings too. The connection screen includes update controls before login, and **Copy Update Diagnostics** copies version/state plus the last 40 local update events. Events are stored in `%APPDATA%\Voxora\updates\update-events.jsonl`, with bounded log size. Diagnostics omit signed download URLs, credentials and private chat data.

## Publishing a release

The source checkout includes a release pusher. Install Node.js 22+, Git, and Git LFS, run `npm ci`, and authenticate Git for write access to **Whoops-Lambo/Voxora**. Use your usual Git credential manager; no token belongs in the application, source, feed, or downloaded bot starter.

1. Finish and test the source changes. Increase the stable version with `npm version patch --no-git-tag-version` (or choose the next minor version). Update documentation/download links as appropriate. Add optional release notes at `docs/releases/<version>.md`, up to 8,000 characters.
2. Commit those source changes. The pusher requires a clean working tree and a newer stable version; it never automatically commits unrelated work or force-pushes.
3. Preview with `npm run release:push -- --dry-run`.
4. Run **`npm run release:push`**, or double-click **`push-update.bat`** on Windows. You can use `--notes-file path/to/notes.md` for another notes file.
5. After publishing, open **Platform Admin → Updates → Notify Desktop Clients** on your shared backend to request an immediate check. This is owner-only, audited, and limited to once a minute. Apps that are offline or connected elsewhere check on their own schedule.

The pusher checks remote ancestry, runs syntax/backend tests, builds the Windows app, verifies its ASAR files against the committed source, and generates the source ZIP. It commits the installer through Git LFS, its SHA-256 manifest, and `Voxora.zip`; a second commit adds the feed pinned to the first commit. Both commits are pushed together to main, after LFS uploads complete. Keep full browser regression testing in your release routine (`npm run test:ui`).

The source ZIP includes the SDK, bot starter, updater, installer script, release pusher, and Docker/Compose/Caddy shared-hosting configuration. It excludes installers, runtime chat/economy data, `.env` credentials, and the mutable update feed, which is published after the artifact commit. Windows builds use `build/windows.cjs` to allow the pinned NSIS compressor up to ten minutes on slower machines, without changing installer behavior.

`npm run release:push -- --reuse-build` reuses an existing `dist` build after the same source/bundle verification; use it only for a build you just completed and tested. Installer files and versions are immutable: publish a newer version rather than replacing an existing release.

## Recovering from failures

- **Download interrupted, offline, or checksum failed:** the partial file is discarded, the existing app keeps running, and the Updates screen offers another download. A completed verified update survives app restarts. Close/reopen the app if a manual check was just throttled; normal checks retry automatically.
- **Restart declined:** the verified installer stays cached until you choose Restart and Install.
- **Helper cannot start:** Voxora stays open. Open `%APPDATA%\Voxora\updates\install-helper-output.log` for PowerShell startup errors and `install-update.log` for the handoff failure. Retry or run the official installer manually.
- **Installation failed:** the helper records the result and attempts to reopen Voxora, which displays the failure and log location. If relaunch fails, a Windows dialog directs you to the manual installer and log. `install-update.log` records verification, shutdown, installer exit and startup confirmation. The helper never force-kills a stuck app.
- **Release upload failed:** local release commits are retained. Run `npm run release:push -- --resume` from the clean checkout to finish the same release; the pusher rechecks the committed installer checksum and feed. Do not reset or overwrite a version to retry. If main advanced, merge/rebase your unpublished commits, then resume without force-pushing.
- **Old shared backend:** the app's native updater works independently of the backend. Its web UI may lack the Updates tab and owner notification control until you upgrade that backend.

The updater cache is under `%APPDATA%\Voxora\updates`; it is separate from chat data. Installation messages, installer paths, and update preferences are local desktop state, never exposed through server administration APIs. A server owner can ask clients to check the official feed; they cannot choose an executable URL, bypass verification, or force a restart.

## Push this update to installed apps

Voxora 2.16.0 is published through the official feed. Sign in to your shared Voxora backend as the first-account platform owner, open **Platform Admin → Updates**, then select **Notify Desktop Clients**. Connected Windows apps running 2.8+ check the feed immediately. Users choose **Restart and Install** from User Settings → Updates when the download is ready. If an earlier updater closes without reopening the app, install 2.15.1 manually once. Apps that are offline check after reconnect/startup or on their normal interval. Copies before 2.14 keep their earlier polling schedule until upgraded. Copies on 2.7 or earlier also need the new installer manually. The notification sends a check request; it does not upload a release or force a restart.

For a future release, work from your Git clone rather than the extracted source ZIP (which has no Git history). After finishing and testing your changes:

```powershell
npm version patch --no-git-tag-version
# Update the download links and docs/releases/<new-version>.md.
git add .
git commit -m "Prepare Voxora update"
.\push-update.bat
```

The batch file runs `npm run release:push`: checks, Windows build, bundle/archive verification, installer and ZIP upload, then the pinned update feed. Git/Git LFS and authenticated GitHub write access must be available; install Node.js 22+ first. Do not change an already-published version in place. Once publishing succeeds, notify clients from Platform Admin → Updates as above.

Shared backends still need their own deployment: back up the data directory, update the source with `git pull`, and restart the Node service using its existing `VOXORA_DATA_DIR`, host, port and environment settings. Preserve state.json, uploads, server connections and external bot data. A desktop updater only upgrades the app/local bundled backend; it cannot deploy your hosted Node service.

To execute the helper integration tests with PowerShell 7 installed, set `VOXORA_POWERSHELL_PATH` to its executable path and run `npm test`. On Linux these tests run the real helper script, replacing only the Windows installer/app processes with fixtures; they do not validate native Windows APIs. Without that variable, the six integration scenarios are skipped. The ordinary updater tests still run. The shipped script uses Windows PowerShell 5.1-compatible syntax.

Voxora 2.12.1 could mistake a stale NSIS error flag for a failed copy and incorrectly say to close Voxora. Install 2.12.2 over the same folder; do not delete chat data. Real destination failures now identify the affected folder/file. Expand the installer details to see that path and check its permissions or file locks.

The Windows installer workflow runs the compiled file-operation regressions plus a production install/start/reinstall/uninstall smoke test. The three regression scenarios also run locally when `VOXORA_NSIS_PATH` names makensis and the host is Windows, or when `VOXORA_WINE_PATH` also names a working Wine installation on Linux. They require actual Windows execution support; without it the three cases are skipped.

The 2.12.2 Windows verification passed: [native installer regression and production smoke tests](https://github.com/Whoops-Lambo/Voxora/actions/runs/41231795245). The production smoke test requires a matching startup receipt from the installed desktop, not merely a listening backend port.

The earlier 2.13.0 [native Windows verification](https://github.com/Whoops-Lambo/Voxora/actions/runs/41240860967) passed all 12 connection/member/forum/installer cases and the production smoke test. It checks first-launch setup without an implicit backend, explicit private hosting, connection to a shared backend with exactly one first-account owner, preservation of private data when switching to a shared connection, and reinstall/uninstall preservation. The full browser suite passed all 42 scenarios, including delayed Do Not Disturb responses, member search on mobile, live forum discussions and permission revocation. The local backend/helper run passed 67 tests; its three native installer scenarios were exercised on Windows instead.

The 2.14.0 [Windows validation](https://github.com/Whoops-Lambo/Voxora/actions/runs/41265681826) passed all 20 native regression cases and the complete production smoke test, including independent helper lifetime after the GUI parent exits, real installer execution and desktop relaunch from a Unicode/bracketed installation path. The update test supplies fixture network responses for the production installer; executable processes are real. Separately, live download verification used the official public GitHub fallback. All 45 browser scenarios passed, and local backend/helper checks passed 74 cases with four Windows-only scenarios covered natively.

The 2.15.0 [Windows validation](https://github.com/Whoops-Lambo/Voxora/actions/runs/41364535659) also performs an actual 2.14 → 2.15 upgrade. It verifies the published 2.14 installer against its immutable SHA-256, installs it, extracts its unmodified updater and PowerShell scripts, and exercises their scheduled feed discovery, background download, helper handoff, production installation and app relaunch. A second cycle validates the candidate updater. Both use fixture network responses containing the real candidate installer. Desktop data and saved connections survive both cycles. All 47 browser scenarios and 79 applicable local backend/helper checks passed.

The 2.15.1 [Windows validation](https://github.com/Whoops-Lambo/Voxora/actions/runs/41372827481) adds the missing confirmation timing case. The production confirmation method is held open during a pending feed check and focus/wake requests, then approved before real helper handoff, installation and relaunch. Local regression coverage reproduces the exact old error and tests Later, duplicate requests, dialog failure, changed release metadata and cache tampering. The Windows updater/installer suite passed 33 cases, local checks passed 83 applicable cases, and all three update browser scenarios passed.

The 2.16.0 [Windows validation](https://github.com/Whoops-Lambo/Voxora/actions/runs/41377558295) upgrades from the SHA-256-verified published 2.15.1 installer with its unmodified updater/helper scripts. Both the candidate and the shipped 2.15.1 updater pass automatic discovery/download, pending checks during confirmation, real installer execution and relaunch. Local/shared connections and account data survive installation, reinstallation and uninstallation. All 50 browser scenarios and 89 applicable local backend/helper checks passed.
