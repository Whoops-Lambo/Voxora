public let isCapacitorApp = true
