import './install.js';
import { createBotUI } from "./bot-ui.js";
import { createPremiumUI } from './premium-ui.js';
const $ = (id) => document.getElementById(id);
const node = (tag, cls = "", content) => {
  const e = document.createElement(tag);
  e.className = cls;
  if (content !== undefined)
    e.append(...(Array.isArray(content) ? content : [content]));
  return e;
};
const safe = (fn) => async (event) => {
  try {
    return await fn(event);
  } catch (e) {
    toast(e.message, true);
  }
};
function button(label, fn, cls = "secondary") {
  const b = node("button", cls, label);
  b.type = "button";
  b.onclick = safe(fn);
  return b;
}
function input(value = "", placeholder = "", type = "text") {
  const e = node("input");
  e.type = type;
  e.value = value;
  e.placeholder = placeholder;
  return e;
}
function field(label, control) {
  control.setAttribute("aria-label", label);
  return node("label", "", [label, control]);
}
function toast(message, error = false) {
  const item = node("div", "toast" + (error ? " error" : ""), message);
  $("toast-stack").append(item);
  setTimeout(() => item.remove(), 6000);
}
function modal(children) {
  $("modal-content").replaceChildren(...children);
  if (!$("modal").open) $("modal").showModal();
}
$("modal-close").onclick = () => $("modal").close();
$("modal").addEventListener("click", (e) => {
  if (e.target === $("modal")) {
    const r = $("modal").getBoundingClientRect();
    if (
      e.clientX < r.left ||
      e.clientX > r.right ||
      e.clientY < r.top ||
      e.clientY > r.bottom
    )
      $("modal").close();
  }
});
function formDialog({
  title,
  description,
  fields,
  submit,
  submitLabel = "Save Changes",
  danger = false,
}) {
  const form = node("form"),
    error = node("div", "form-error"),
    save = node("button", danger ? "danger-button" : "primary", submitLabel);
  save.type = "submit";
  form.append(node("h2", "", title));
  if (description) form.append(node("p", "", description));
  form.append(
    ...fields,
    error,
    node("div", "modal-footer", [
      button("Cancel", () => $("modal").close()),
      save,
    ]),
  );
  form.onsubmit = async (event) => {
    event.preventDefault();
    save.disabled = true;
    try {
      await submit();
      if (form.isConnected) $("modal").close();
    } catch (e) {
      error.textContent = e.message;
    } finally {
      save.disabled = false;
    }
  };
  modal([form]);
  setTimeout(() => { if(form.isConnected&&!form.contains(document.activeElement))form.querySelector('input,textarea,select')?.focus(); }, 30);
}
function confirmDialog(title, description, fn) {
  formDialog({
    title,
    description,
    fields: [],
    submit: fn,
    submitLabel: "Confirm",
    danger: true,
  });
}
async function copy(text) {
  try {
    await navigator.clipboard.writeText(text);
    toast("Copied.");
  } catch {
    const value = input(text);
    value.readOnly = true;
    modal([node("h2", "", "Copy this value"), value]);
    value.select();
  }
}
async function api(path, method = "GET", data) {
  const r = await fetch("/api" + path, {
    method,
    headers:
      data === undefined ? undefined : { "Content-Type": "application/json" },
    body: data === undefined ? undefined : JSON.stringify(data),
  });
  const value = await r.json();
  if (!r.ok) {
    const e = Error(value.error || "Request failed.");
    e.status = r.status;
    throw e;
  }
  return value;
}
let state = null,
  adminTab = "Overview";
const portalClient='portal-'+crypto.randomUUID();
setInterval(()=>{if(!state?.me)return;api('/state?client='+portalClient).then(next=>{if(state?.me.id===next.me.id){const changed=JSON.stringify(state.platform?.permissions)!==JSON.stringify(next.platform?.permissions);state=next;header();if(changed&&location.pathname==='/admin'){document.getElementById('modal').close();renderAdmin();}}}).catch(error=>{if(error.status===401){state=null;location.assign('/app');}});},10000);
const premiumUI=createPremiumUI({node,button,input,field,formDialog,api,getState:()=>state,refreshState,toast});
async function refreshState() {
  state = await api("/state");
  header();
}
function link(label, href, cls = "secondary") {
  const a = node("a", cls, label);
  a.href = href;
  return a;
}
function header() {
  const box = $("account-nav");
  box.replaceChildren();
  if (state) {
    if (state.platform?.permissions.length)
      box.append(link(state.platform.scope==='private'?'Workspace Admin':'Admin', '/admin', ''));
    box.append(link(state.me.displayName, "/app", ""));
  } else box.append(link("Sign In", "/app", ""));
}
function portal(title, description, eyebrow) {
  const wrapper = node("section", "portal"),
    content = node("div");
  wrapper.append(
    node("div", "portal-heading", [
      node("div", "", [
        node("p", "eyebrow", eyebrow),
        node("h1", "", title),
        node("p", "", description),
      ]),
    ]),
    content,
  );
  $("page").replaceChildren(wrapper);
  document.title = title + " | Voxora";
  return content;
}
function signIn(target, next) {
  target.append(
    node("div", "auth-prompt", [
      node("h2", "", "Make it yours."),
      node("p", "", "Sign in to your Voxora account to continue."),
      node("div", "hero-actions", [
        link("Sign In", "/app?next=" + next, "primary"),
        link("Create Account", "/app?register=1&next=" + next),
      ]),
    ]),
  );
}
const bots = createBotUI({
  node,
  button,
  input,
  field,
  modal,
  formDialog,
  confirmDialog,
  api,
  getState: () => state,
  refreshState,
  toast,
  copy,
});
function userRoles(u) {
  const line = node("div");
  for (const role of u.staffRoles) {
    const badge = node("span", "staff-pill", role.name);
    badge.style.color = role.color;
    line.append(badge);
  }
  return line;
}
async function assignments(u) {
  const data = await api("/platform/staff-roles"),
    boxes = [];
  const fields = data.roles.map((role) => {
    const check = input("", "", "checkbox");
    check.checked = u.staffRoleIds.includes(role.id);
    check.setAttribute("aria-label", role.name);
    boxes.push({ role, check });
    return node("label", "permission-row", [
      node("span", "", role.name),
      check,
    ]);
  });
  if (!fields.length) {
    toast("Create a staff role first.", true);
    return;
  }
  formDialog({
    title: "Voxora Staff Roles — " + u.username,
    description:
      "Platform staff permissions are separate from server roles. Only the platform owner can assign them.",
    fields,
    submitLabel: "Save Staff Roles",
    submit: async () => {
      await api("/platform/users/" + u.id, "PATCH", {
        staffRoleIds: boxes
          .filter((v) => v.check.checked)
          .map((v) => v.role.id),
      });
      await renderAdmin();
    },
  });
}
function suspend(u) {
  const duration = node("select"),
    why = input("", "Why is this account being moderated?");
  why.required = true;
  why.maxLength = 500;
  for (const [seconds, label] of [
    [3600, "1 hour"],
    [86400, "1 day"],
    [604800, "7 days"],
    [-1, "Until restored"],
  ])
    duration.append(new Option(label, String(seconds)));
  formDialog({
    title: (u.suspended ? "Restore " : "Suspend ") + u.username,
    description: u.suspended
      ? "Restore this user’s access to Voxora."
      : "End this account’s sessions and block sign-in and its bot applications for the selected duration.",
    fields: [
      ...(u.suspended ? [] : [field("SUSPENSION DURATION", duration)]),
      field("REASON", why),
    ],
    submitLabel: u.suspended ? "Restore Account" : "Suspend Account",
    danger: !u.suspended,
    submit: async () => {
      await api("/platform/users/" + u.id, "PATCH", {
        suspendFor: u.suspended ? 0 : Number(duration.value),
        reason: why.value,
      });
      await renderAdmin();
    },
  });
}
function staffRoleForm(role, definitions) {
  const name = input(role?.name || "", "Voxora Moderator"),
    color = input(role?.color || "#5865f2", "", "color"),
    boxes = [];
  name.required = true;
  name.maxLength = 40;
  const fields = [
    field("STAFF ROLE NAME", name),
    field("ROLE COLOR", color),
    ...definitions.map((p) => {
      const check = input("", "", "checkbox");
      check.checked = role?.permissions.includes(p.id) || false;
      check.setAttribute("aria-label", p.name);
      boxes.push({ p, check });
      return node("label", "permission-row", [
        node("span", "", [
          node("strong", "", p.name),
          node("small", "", p.description),
        ]),
        check,
      ]);
    }),
  ];
  formDialog({
    title: role ? "Edit Voxora Staff Role" : "Create Voxora Staff Role",
    fields,
    submitLabel: "Save Staff Role",
    submit: async () => {
      await api(
        "/platform/staff-roles" + (role ? "/" + role.id : ""),
        role ? "PATCH" : "POST",
        {
          name: name.value,
          color: color.value,
          permissions: boxes.filter((b) => b.check.checked).map((b) => b.p.id),
        },
      );
      await renderAdmin();
    },
  });
}
function deleteServer(s) {
  const confirmation = input("", "Type " + s.name),
    reason = input("", "Moderation reason");
  confirmation.required = true;
  reason.required = true;
  reason.maxLength = 500;
  formDialog({
    title: "Remove " + s.name,
    description:
      "This permanently removes the server, its channels, and its messages. Type the server name to confirm.",
    fields: [
      field("CONFIRM SERVER NAME", confirmation),
      field("REASON", reason),
    ],
    submitLabel: "Remove Server",
    danger: true,
    submit: async () => {
      await api("/platform/servers/" + s.id, "DELETE", {
        confirmation: confirmation.value,
        reason: reason.value,
      });
      await renderAdmin();
    },
  });
}
function moderateApp(a) {
  const reason = input("", "Moderation reason");
  reason.required = true;
  reason.maxLength = 500;
  formDialog({
    title: (a.disabled ? "Restore " : "Disable ") + a.name,
    description:
      "Disabling stops its bot API, gateway connections, and installed commands. Existing messages and installations are preserved.",
    fields: [field("REASON", reason)],
    submitLabel: a.disabled ? "Restore Application" : "Disable Application",
    danger: !a.disabled,
    submit: async () => {
      await api("/platform/applications/" + a.id, "PATCH", {
        disabled: !a.disabled,
        reason: reason.value,
      });
      await renderAdmin();
    },
  });
}
function record(title, lines, actions = [], badges) {
  const item = node("article", "admin-record", [
    node("h3", "", title),
    ...lines.map((line) => node("p", "", line)),
  ]);
  if (badges) item.append(badges);
  if (actions.length) item.append(node("div", "bot-actions", actions));
  return item;
}
async function adminList(content, kind, overview) {
  const search = input("", "Search " + kind),
    form = node("form", "admin-search"),
    list = node("div");
  search.setAttribute("aria-label", "Search " + kind);
  const submit = node("button", "primary", "Search");
  submit.type = "submit";
  form.append(search, submit);
  content.append(form, list);
  let offset = 0,
    more,
    loadVersion = 0;
  const renderItem = (v) => {
    if (kind === "users") {
      const actions = [];
      if (overview.owner && !v.owner)
        actions.push(button("Assign Staff Roles", () => assignments(v)));
      if (
        !v.owner &&
        v.id !== state.me.id &&
        (overview.owner || !v.staffRoles.length)
      )
        actions.push(
          button(
            v.suspended ? "Restore Account" : "Suspend Account",
            () => suspend(v),
            v.suspended ? "secondary" : "danger",
          ),
        );
      return record(
        v.displayName + " · @" + v.username,
        [
          v.suspended ? "Suspended · " + v.suspensionReason : "Active account",
          "Joined " + new Date(v.createdAt).toLocaleDateString(),
        ],
        actions,
        userRoles(v),
      );
    }
    if (kind === "servers")
      return record(
        v.name,
        [
          "Owner: @" + v.owner,
          v.memberCount + " members · " + v.channelCount + " channels",
        ],
        [button("Remove Server", () => deleteServer(v), "danger")],
      );
    if (kind === "applications")
      return record(
        v.name + (v.builtin ? " · Built-in" : ""),
        [
          "Developer: " + v.owner,
          v.installedServers +
            " installations · " +
            (v.disabled ? "Disabled: " + v.reason : "Enabled"),
        ],
        v.builtin && !overview.owner
          ? []
          : [
              button(
                v.disabled ? "Restore Application" : "Disable Application",
                () => moderateApp(v),
                v.disabled ? "secondary" : "danger",
              ),
            ],
      );
    return record(v.action, [
      v.actorName + " · " + v.target,
      new Date(v.time).toLocaleString(),
      v.reason || "No reason supplied",
    ]);
  };
  async function load(reset = false) {
    const version = ++loadVersion;
    const data = await api(
      "/platform/" +
        kind +
        "?" +
        new URLSearchParams({
          q: search.value,
          offset: String(reset ? 0 : offset),
        }),
    );
    if (!content.isConnected || version !== loadVersion) return;
    if (reset) {
      offset = 0;
      list.replaceChildren();
    }
    more?.remove();
    if (!data.items.length && !offset)
      list.append(node("p", "muted", "No matching records."));
    for (const item of data.items) list.append(renderItem(item));
    offset += data.items.length;
    if (data.hasMore) {
      more = button("Load More", () => load(), "secondary");
      list.append(more);
    }
  }
  form.onsubmit = safe(async (e) => {
    e.preventDefault();
    await load(true);
  });
  await load(true);
}
function boostGrantForm(server,done){
 const level=node('select'),duration=input(30,'','number'),unit=node('select'),reason=node('textarea');
 for(const n of[1,2,3,4,5])level.append(new Option('Level '+n,n));level.value=server.boosts.level||3;
 for(const [name,value]of[['Days','days'],['Hours','hours'],['Minutes','minutes'],['Unlimited time','unlimited']])unit.append(new Option(name,value));
 duration.min=1;duration.max=3660;reason.maxLength=500;reason.required=true;duration.required=true;
 const hint=node('p','bot-help','The grant sets a minimum level. Active member boosts can still provide a higher level. Revoking a grant restores the level earned by member boosts.');
 unit.onchange=()=>{duration.disabled=unit.value==='unlimited';duration.required=!duration.disabled;duration.max=unit.value==='minutes'?5270400:unit.value==='hours'?87840:3660;};
 formDialog({title:'Boost Level — '+server.name,description:'Grant a server boost level for a set period or unlimited time.',fields:[field('BOOST LEVEL',level),field('DURATION',duration),field('DURATION UNIT',unit),field('REASON',reason),hint],submitLabel:'Grant Boost Level',submit:async()=>{const expiresAt=unit.value==='unlimited'?null:Date.now()+Number(duration.value)*({minutes:60000,hours:3600000,days:86400000}[unit.value]);await api('/platform/server-boosts/'+server.id,'PATCH',{version:server.version,level:Number(level.value),expiresAt,reason:reason.value});await done();toast('Server boost grant saved.');}});
}
async function boostAdmin(content){
 const search=input('','Search servers'),form=node('form','admin-search'),list=node('div'),submit=node('button','primary','Search');submit.type='submit';search.setAttribute('aria-label','Search boost servers');form.append(search,submit);content.append(node('p','bot-help','Manage timed or unlimited boost grants. Level 3 unlocks custom invite links. This permission can be assigned through Voxora Staff Roles.'),form,list);let offset=0,generation=0;
 async function load(){const request=++generation;const data=await api('/platform/server-boosts?q='+encodeURIComponent(search.value)+'&offset='+offset);if(request!==generation||!content.isConnected)return;list.replaceChildren();for(const s of data.items){const g=s.grant,active=g?.level&&(!g.expiresAt||g.expiresAt>Date.now());list.append(record(s.name,['Level '+s.boosts.level+' · '+s.boosts.count+' member boosts · Earned level '+s.boosts.naturalLevel,active?'Granted level '+g.level+' · '+(g.expiresAt?'Until '+new Date(g.expiresAt).toLocaleString():'Unlimited time'):g?.level?'Previous grant expired':'No active grant',s.owner+' · '+s.memberCount+' members',...(g?.reason?['Grant reason: '+g.reason]:[])],[button(active?'Change Boost Grant':'Grant Boost Level',()=>boostGrantForm(s,load),'primary'),...(active?[button('Revoke Boost Grant',()=>{const reason=node('textarea');reason.maxLength=500;reason.required=true;formDialog({title:'Revoke Boost Grant — '+s.name,description:'The server keeps the level earned from active member boosts.',fields:[field('REASON',reason)],submitLabel:'Revoke Boost Grant',danger:true,submit:async()=>{await api('/platform/server-boosts/'+s.id,'PATCH',{version:s.version,level:0,expiresAt:null,reason:reason.value});await load();}});},'danger')]:[])]));}if(!data.items.length)list.append(node('p','bot-empty','No matching servers.'));const pages=node('div','bot-actions');if(offset)pages.append(button('Previous Servers',()=>{offset=Math.max(0,offset-25);return load();}));if(data.hasMore)pages.append(button('Next Servers',()=>{offset+=25;return load();}));list.append(pages);}
 form.onsubmit=event=>{event.preventDefault();offset=0;load().catch(e=>toast(e.message,true));};await load();
}
async function platformReportsAdmin(content){
 const filter=node('select'),source=node('select'),search=input('','Search reports'),form=node('form','admin-search'),list=node('div'),summary=node('p','bot-help');for(const [value,label]of [['open','Open reports'],['reviewing','Under review'],['resolved','Resolved'],['dismissed','Dismissed'],['all','All reports']])filter.append(new Option(label,value));filter.setAttribute('aria-label','Report status');for(const [value,label]of [['all','All report sources'],['server','Server reports'],['safety','Anonymous Safety Center']])source.append(new Option(label,value));source.setAttribute('aria-label','Report source');search.setAttribute('aria-label','Search reports');form.append(filter,source,search,button('Refresh Reports',()=>load()));content.append(node('p','bot-help','Review anonymous Safety Center submissions, reports from channels you can access and evidence explicitly shared with Voxora staff. Private channel history and server staff notes are not included.'),form,summary,list);let generation=0,offset=0,reportTimer;
 async function detail(id){const report=await api('/platform/reports/'+id),status=node('select'),reason=input('','Review reason'),claim=input('','','checkbox');for(const value of ['open','reviewing','resolved','dismissed'])status.append(new Option(value,value));status.value=report.status;status.setAttribute('aria-label','Report status');claim.checked=report.assigneeId===state.me.id;claim.disabled=!['open','reviewing'].includes(report.status);reason.maxLength=500;
  const evidence=node('div','admin-record',[node('strong','',report.serverName+' · '+report.channelName),node('p','',report.evidence.authorName),node('pre','report-evidence',report.evidence.text)]);if(report.anonymous)evidence.prepend(node('p','plus-test','Anonymous report · submitted information has not been independently verified. No reporter account, name or email is attached.'));for(const address of report.evidenceLinks||[]){const a=node('a','text-link',address);a.href=address;a.target='_blank';a.rel='noopener noreferrer';evidence.append(a);}for(const r of report.reporters)evidence.append(node('p','',r.name+' · '+r.reason),node('p','',r.details||'No details provided'));
  formDialog({title:'Review Report '+report.number,fields:[evidence,field('REPORT STATUS',status),field('REVIEW REASON',reason),field('Assign to me',claim)],submitLabel:'Update Report',submit:async()=>{await api('/platform/reports/'+id,'PATCH',{version:report.version,status:status.value,resolution:reason.value,...(!claim.disabled?{claim:claim.checked}:{})});await load();toast('Report updated.');}});
 }
 async function load(){clearTimeout(reportTimer);if(!content.isConnected)return;const request=++generation;try{const data=await api('/platform/reports?status='+filter.value+'&source='+source.value+'&q='+encodeURIComponent(search.value)+'&offset='+offset);if(!content.isConnected||request!==generation)return;summary.textContent=data.counts.open+' open · '+data.counts.mine+' assigned to you';list.replaceChildren();for(const r of data.items)list.append(record('Report '+r.number+' · '+r.serverName,[r.status+' · '+r.evidence.authorName,...(r.anonymous?['Anonymous website report']:[]),r.evidence.text.slice(0,180),r.reporters.length+' reporter(s)',r.assigneeName?'Assigned: '+r.assigneeName:'Unassigned'],[button('Review Report',()=>detail(r.id),'primary')]));if(!data.items.length)list.append(node('p','bot-help','No reports match this filter.'));const pages=node('div','portal-actions');if(offset)pages.append(button('Previous Reports',()=>{offset=Math.max(0,offset-25);return load();}));if(data.hasMore)pages.append(button('Next Reports',()=>{offset+=25;return load();}));list.append(pages);}catch(error){if(content.isConnected){summary.textContent=error.message;if(error.status===403){list.replaceChildren();document.getElementById('modal').close();}}}finally{if(content.isConnected&&request===generation)reportTimer=setTimeout(load,10000);}}
 form.onsubmit=event=>{event.preventDefault();offset=0;load();};filter.onchange=source.onchange=()=>{offset=0;load();};await load();
}
async function verificationAdmin(content){
  const form=node('form','admin-search'),search=input('','Search servers, IDs or owners'),status=node('select'),list=node('div'),summary=node('p','bot-help');search.setAttribute('aria-label','Search server verification');status.setAttribute('aria-label','Verification status');for(const [value,label]of [['all','All servers'],['verified','Verified'],['unverified','Unverified']])status.append(new Option(label,value));
  form.append(search,status,button('Search Verification',()=>load()));content.append(node('p','bot-help','Verification is a staff review decision, separate from boosts. Review the server’s identity before granting a badge. Name or ownership changes remove verification automatically. A badge does not guarantee member conduct.'),form,summary,list);let offset=0,generation=0;
  function decision(server){const verified=!server.verification.verified,reason=input('','Why are you granting or revoking verification?'),reviewed=input('','','checkbox');reason.required=true;reason.minLength=3;reason.maxLength=500;reviewed.required=verified;
    formDialog({title:(verified?'Verify ':'Revoke Verification — ')+server.name,description:'Server ID: '+server.id+' · Owner: @'+server.owner,fields:[field('VERIFICATION REASON',reason),...(verified?[field('I reviewed the current server name and owner',reviewed)]:[])],submitLabel:verified?'Grant Verification':'Revoke Verification',danger:!verified,submit:async()=>{await api('/platform/server-verifications/'+server.id,'PATCH',{version:server.version,verified,reason:reason.value,reviewed:reviewed.checked,name:server.name,ownerId:server.ownerId});await load();toast(verified?'Server verified.':'Server verification revoked.');}});
  }
  async function load(){const request=++generation,data=await api('/platform/server-verifications?q='+encodeURIComponent(search.value)+'&status='+status.value+'&offset='+offset);if(!content.isConnected||request!==generation)return;summary.textContent=data.total+' server(s)';list.replaceChildren();for(const server of data.items)list.append(record(server.name,[server.verification.verified?'✓ Verified server':'Unverified','@'+server.owner+' · '+server.memberCount+' members','Server ID: '+server.id,...(server.reason?['Review note: '+server.reason]:[])],[button(server.verification.verified?'Revoke Verification':'Verify Server',()=>decision(server),server.verification.verified?'danger':'primary')]));const pages=node('div','portal-actions');if(offset)pages.append(button('Previous Servers',()=>{offset=Math.max(0,offset-25);return load();}));if(data.hasMore)pages.append(button('Next Servers',()=>{offset+=25;return load();}));list.append(pages);}
  form.onsubmit=event=>{event.preventDefault();offset=0;load().catch(error=>toast(error.message,true));};status.onchange=()=>{offset=0;load().catch(error=>toast(error.message,true));};await load();
}
async function renderAdmin() {
  const target = portal(
    "Platform Admin",
    "Manage this Voxora installation, moderate accounts, and assign platform staff permissions.",
    "VOXORA STAFF",
  );
  if (!state) {
    signIn(target, "admin");
    return;
  }
  let overview;
  try {
    overview = await api("/platform/overview");
  } catch (e) {
    target.append(
      node("div", "auth-prompt", [
        node("h2", "", "Staff access required"),
        node("p", "", e.message),
        link("Open Voxora", "/app", "primary"),
      ]),
    );
    return;
  }
  const p = overview.permissions,
    tabs = ["Overview"];
  if (overview.owner || p.includes("manageUsers")) tabs.push("Accounts");
  if (p.includes("manageServers")) tabs.push("Servers");
  if (p.includes('manageBoosts')) tabs.push('Server Boosts');
  if(p.includes('reviewReports'))tabs.push('Reports');
  if(p.includes('verifyServers'))tabs.push('Server Verification');
  if (p.includes("manageApplications")) tabs.push("Bot Applications");
  if (overview.owner) tabs.push("Staff Roles");
  if (overview.owner) tabs.push("Updates");
  if (overview.owner) tabs.push('Plus','Server Shops');
  if (p.includes("viewAudit")) tabs.push("Audit Log");
  if (!tabs.includes(adminTab)) adminTab = "Overview";
  const nav = node("nav", "admin-nav", [
      node("p", "", overview.owner ? (overview.scope==='private'?'WORKSPACE OWNER':'PLATFORM OWNER') : 'PLATFORM STAFF'),
    ]),
    content = node("div", "admin-content");
  for (const tab of tabs)
    nav.append(
      button(
        tab,
        () => {
          adminTab = tab;
          return renderAdmin();
        },
        tab === adminTab ? "active" : "",
      ),
    );
  target.append(node("div", "admin-layout", [nav, content]));
  content.append(node("h2", "", adminTab));
  if (adminTab === "Overview") {
    const stats = node("div", "admin-stats");
    for (const [key, label] of [
      ["users", "Human accounts"],
      ["servers", "Servers"],
      ["applications", "Custom bot applications"],
      ["suspended", "Suspended accounts"],
    ])
      stats.append(
        node("div", "admin-stat", [
          node("strong", "", String(overview.stats[key])),
          node("small", "", label),
        ]),
      );
    content.append(
      stats,
      node(
        "p",
        "bot-help",
        "Platform roles grant moderation tools across this installation. They do not grant access to private conversations or bypass server channel permissions. The first registered human account owns the platform.",
      ),
    );
    if(p.includes('reviewReports')){const reports=await api('/platform/reports');if(content.isConnected)content.append(record('Open Reports',[reports.counts.open+' open report(s)',reports.counts.mine+' assigned to you'],[button('Review Reports',()=>{adminTab='Reports';return renderAdmin();},'primary')]));}
  } else if(adminTab==='Reports'){
    await platformReportsAdmin(content);
  } else if(adminTab==='Server Verification'){
    await verificationAdmin(content);
  } else if(adminTab==='Server Boosts') {
    await boostAdmin(content);
  } else if(adminTab==='Server Shops') {
    const config=await api('/platform/shop-configuration'),fee=input(String(config.feeBasisPoints/100),'','number');fee.min=5;fee.max=10;fee.step=.01;
    content.append(node('h2','','Server Shop Payments'),node('p','','Server owners receive direct payments through Stripe Connect. The platform fee applies to the item subtotal and excludes shipping; Stripe processing fees are separate.'),node('p','',config.ready?'Stripe Connect is configured.':'Missing configuration: '+config.missing.join(', ')),field('VOXORA PLATFORM FEE (%)',fee),button('Save Platform Fee',async()=>{await api('/platform/shop-configuration','PATCH',{feeBasisPoints:Math.round(Number(fee.value)*100)});toast('Shop fee saved for future checkouts.');},'primary'));
  } else if(adminTab==='Plus') {
    await premiumUI.admin(content);
  } else if (adminTab === "Updates") {
    const info = await api("/platform/updates");
    content.append(record("Desktop Updates", [
      "This backend runs Voxora " + info.backendVersion + ".",
      "Publish a release from the source checkout with npm run release:push. Installed Windows apps check automatically and verify the installer before offering a restart.",
      "Notify connected desktop clients to check now. Each app checks the official release feed; restarting remains the user's choice. This does not upgrade the hosted backend.",
      info.lastNotifiedAt ? "Last notification: " + new Date(info.lastNotifiedAt).toLocaleString() : "No update notification has been sent yet.",
    ], [button("Notify Desktop Clients", async () => { await api("/platform/updates/notify", "POST", {}); toast("Connected desktop clients were asked to check for updates."); await renderAdmin(); }, "primary")]));
  } else if (adminTab === "Staff Roles") {
    const data = await api("/platform/staff-roles");
    if (!content.isConnected) return;
    content.append(
      button(
        "Create Staff Role",
        () => staffRoleForm(null, data.permissions),
        "primary",
      ),
    );
    if (!data.roles.length)
      content.append(
        node(
          "p",
          "bot-empty",
          "Create a staff role, choose its permissions, then assign it from Accounts.",
        ),
      );
    for (const r of data.roles)
      content.append(
        record(
          r.name,
          [
            r.permissions
              .map((id) => data.permissions.find((p) => p.id === id)?.name)
              .join(" · ") || "No admin tools enabled",
          ],
          [
            button("Edit Staff Role", () => staffRoleForm(r, data.permissions)),
            button(
              "Delete Staff Role",
              () =>
                confirmDialog(
                  "Delete " + r.name,
                  "Remove this staff role and all its assignments?",
                  async () => {
                    await api("/platform/staff-roles/" + r.id, "DELETE");
                    await renderAdmin();
                  },
                ),
              "danger",
            ),
          ],
        ),
      );
  } else
    await adminList(
      content,
      {
        Accounts: "users",
        Servers: "servers",
        "Bot Applications": "applications",
        "Audit Log": "audit",
      }[adminTab],
      overview,
    );
}
function docs() {
  const target = portal(
    "Build a Voxora bot",
    "Start with the SDK, register commands, and connect your bot to the same backend as your community.",
    "DEVELOPER DOCUMENTATION",
  );
  target.className = "docs-content";
  target.append(
    link(
      "Download Bot Starter",
      "/downloads/voxora-bot-starter.zip",
      "primary",
    ),
    node("h2", "", "From application to first command"),
  );
  const list = node("ol");
  for (const text of [
    "Open Developer Portal, create an application, and copy its one-time bot token.",
    "Install the bot in a server where you have Manage Server. Its roles and channel restrictions control access.",
    "Download and extract the starter, then install Node.js 22 or later. On Windows, double-click start-bot.bat in the extracted folder; the first launch opens .env for your server URL and token.",
    "Upgrade to Voxora 2.5 or later. Save .env and launch start-bot.bat again, or run node start-bot.mjs from a terminal. The community template registers 25 moderation, economy, and utility commands; use /bothelp. Keep that process running to keep your bot online.",
  ])
    list.append(node("li", "", text));
  target.append(
    list,
    node("h3", "", "Run the starter"),
    node(
      "pre",
      "",
      "# Windows: double-click start-bot.bat.\n# Any terminal: run this, edit the generated .env, then run again.\nnode start-bot.mjs",
    ),
    node("h3", "", "Use the SDK"),
    node(
      "pre",
      "",
      'import { VoxoraBot } from "./sdk/voxora.mjs";\nconst bot = new VoxoraBot({\n  url: process.env.VOXORA_URL,\n  token: process.env.VOXORA_BOT_TOKEN,\n});\nawait bot.registerCommands([{ name: "hello", description: "Say hello" }]);\nbot.on("interaction", async (command) => {\n  await command.respond("Hello, " + command.user.displayName + "!");\n});\nawait bot.connect();',
    ),
    node("h2", "", "REST API"),
    node(
      "p",
      "",
      "Send Authorization: Bot <your token> to bot endpoints. HTTPS is required outside localhost. Tokens are not accepted in URLs and are never returned by listing endpoints.",
    ),
  );
  const table = node("table"),
    head = node("tr", "", [
      node("th", "", "Method & route"),
      node("th", "", "Purpose"),
    ]);
  table.append(head);
  for (const [route, purpose] of [
    ["GET /api/bot/me", "Current bot and accessible server/channel metadata"],
    [
      "GET /api/bot/events",
      "SSE gateway: READY, STATE_UPDATE, MESSAGE_CREATE/UPDATE/DELETE, INTERACTION_CREATE",
    ],
    ["PUT /api/bot/commands", "Register up to 25 slash commands"],
    ["GET /api/bot/interactions", "Recover pending command invocations"],
    ["GET /api/bot/interactions/:id/context", "Get current invoker permissions and server/member context (2.5+)"],
    ["POST /api/bot/interactions/:id/moderation", "Moderate with both user and bot permissions, hierarchy and action receipts (2.5+)"],
    [
      "POST /api/bot/interactions/:id/respond",
      "Respond once within 15 minutes",
    ],
    [
      "GET/POST /api/bot/channels/:id/messages",
      "Read accessible history or send text/polls",
    ],
    [
      "PATCH/DELETE /api/bot/messages/:id",
      "Edit own messages or delete with applicable permissions",
    ],
    ["POST /api/bot/messages/:id/reactions", "Toggle a reaction"],
    [
      "POST /api/bot/messages/:id/poll-close",
      "End a poll with applicable permissions",
    ],
  ])
    table.append(
      node("tr", "", [node("td", "", route), node("td", "", purpose)]),
    );
  target.append(
    table,
    node("h2", "", "Permissions and lifecycle"),
    node(
      "p",
      "",
      "Manage Server is required to install and configure bots. Server roles and channel overrides still apply; an installation’s channel list is an additional restriction. Pausing, uninstalling, kicking, banning, token revocation, application suspension, or owner suspension stops the corresponding access. Rotation closes old gateway connections immediately.",
    ),
    node(
      "p",
      "",
      "The gateway does not replay message events. Backfill with message history and deduplicate by message ID after reconnecting. The SDK recovers pending slash commands on reconnect; command responses are accepted once. Bot REST traffic is limited to 300 requests per minute per application, with a further 60-message limit on direct sends.",
    ),
    node(
      "p",
      "",
      "Voxora bots use an independent API. Discord tokens, discord.js, Discord OAuth, bot DMs, bot voice connections, ephemeral replies, and running third-party code inside the Voxora server are not supported.",
    ),
  );
}
async function start() {
  try {
    await refreshState();
  } catch {
    state = null;
    header();
  }
  if (location.pathname === "/developers/docs") docs();
  else if (location.pathname === "/developers") {
    const target = portal(
      "Developer Portal",
      "Build, manage, and install your own Voxora bot applications.",
      "YOUR APPS. YOUR IDEAS.",
    );
    if (state) await bots.developer(target);
    else signIn(target, "developers");
  } else if (location.pathname === "/admin") await renderAdmin();
  else if(location.pathname==='/plus')await premiumUI.publicPage(portal('Voxora Plus','Express yourself and support your communities.','MAKE IT YOURS'));
  if (location.pathname === "/") {
    try {
      const info = await api("/info");
      for (const a of document.querySelectorAll("[data-windows-download]"))
        a.href =
          "https://github.com/Whoops-Lambo/Voxora/raw/refs/heads/main/installers/Voxora-Setup-" +
          encodeURIComponent(info.version) +
          ".exe";
    } catch {}
  }
}
start().catch((e) => toast(e.message, true));
